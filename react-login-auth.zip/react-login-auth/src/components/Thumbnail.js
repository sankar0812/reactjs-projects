import React from 'react';

function Thumbnail({ url }) {
  return <img src={url} alt="Video thumbnail" />;
}

export default Thumbnail;
