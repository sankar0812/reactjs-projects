// import Thumbnail from './Thumbnail';
// import LikeButton from './LikeButton';


// function Video({ video }) {
//   return (
//     <div>
//       <Thumbnail video={video} />
//       <a href={video.url}>
//         <h3>{video.title}</h3>
//         <p>{video.description}</p>
//       </a>
//       <LikeButton video={video} />
//     </div>
//   );
// }

import React from 'react';
import Thumbnail from './Thumbnail';
import LikeButton from './LikeButton';

function Video({ videos }) {
  return (
    <div>
      <h2>{videos.title}</h2>
      <p>{videos.description}</p>
      <Thumbnail url={videos.thumbnailUrl} />
      <a href={videos.url} target="_blank" rel="noopener noreferrer">Watch Video</a>
      <LikeButton likes={videos.likes} />
    </div>
  );
}

export default Video;
