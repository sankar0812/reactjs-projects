import React, { useState } from 'react';

function LikeButton({ likes }) {
  const [count, setCount] = useState(likes);

  return (
    <button onClick={() => setCount(count + 1)}>
      👍 {count}
    </button>
  );
}

export default LikeButton;
