import logo from './logo.svg';
import './App.css';
import React from 'react';
import Video from './components/Video';

const videoData = {
  title: 'Sample Video',
  description: 'This is a sample video description.',
  url: 'https://youtu.be/e42hIYkvxoQ?si=UcXgs3cYTqs55jyC',
  thumbnailUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnTCIDEyCMi2odFOfCZ5V7WABnmf9UDVFHTg&s',
  likes: 0,
};
const videoData1 = {
  title: 'Sample Video-2',
  description: 'This is a sample video-2 description.',
  url: 'https://youtu.be/e42hIYkvxoQ?si=UcXgs3cYTqs55jyC',
  thumbnailUrl: 'https://www.clipartmax.com/png/small/193-1931865_create-design-logo-online-free-vector-and-clip-art-free-logo-design.png',
  likes: 0,
};


function App() {
  return (
    <div className="App">
      <Video videos={videoData} />
      <Video videos={videoData1} />
    </div>
  );
}

export default App;



