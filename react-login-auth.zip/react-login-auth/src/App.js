// import logo from './logo.svg';
// import './App.css';
// import React from 'react';
// import Video from './components/Video';

// const videoData = {
//   title: 'Sample Video',
//   description: 'This is a sample video description.',
//   url: 'https://youtu.be/e42hIYkvxoQ?si=UcXgs3cYTqs55jyC',
//   thumbnailUrl: 'https://cdndfstest.toruslowcode.com/Torus9x/MongoDB%20%281%29.png',
//   likes: 0,
// };

// function App() {
//   return (
//     <div className="App">
//       <Video video={videoData} />
//     </div>
//   );
// }

// export default App;



