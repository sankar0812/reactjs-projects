import React, { useState } from 'react';
import './Login.css'; // optional styling

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    alert(`Logging in with Email: ${email}, Password: ${password}`);
    // add real authentication logic here
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleSubmit} className="login-form">
        <label>Email:</label>
        <input type="email" value={email} onChange={event => setEmail(event.target.value)} required />
        
        <label>Password:</label>
        <input type="password" value={password} onChange={event => setPassword(event.target.value)} required />

        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;
