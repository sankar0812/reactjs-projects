import React from "react";

export default function Contact() {
  return (
    <div>
      <h1>Contact Page</h1>
      <p>Welcome to the contact page!</p>
    </div>
  );
}